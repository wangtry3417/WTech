from inputmask import isapha,isdigit
from part2 import cal_ca_marks,cal_grade,cal_module_marks,return_remarks_comments
import sys

counts = 0
countsA = 0
countsB = 0
countsC = 0
countsF = 0
avg = 0

def init(times):
  if not times >= 1:
    times += 1
    return "*************** Enter information ***************"
  else:
    return

#set a null list type of varable called 'studentMarks'
studentMarks = []
#set a null list type of varable called 'studentModuleMarks'
studentModuleMarks = []

def restart():
  statement = input("Do you want to enter another student record? [Y/y] for Yes, [N/n] for No: ")
  if statement == "Y" or statement == "y":
    init(0)
    return start()
  elif statement == "N" or statement == "n":
    for s in studentMarks:
      studentModuleMarks.append(s["moduleMarks"])
    avg = sum(studentModuleMarks)/counts
    print(f"""
          There is/are {counts} students' record(s) inputted, and the average marks is: {float(avg)}
          Total number of A grade: {countsA}
          Total number of B grade: {countsB}
          Total number of C grade: {countsC}
          Total number of F grade: {countsF}
          """)
  else:
    sys.exit()

def start(step="sname",ts=0):
  try:
    global counts,countsA,countsB,countsC,countsF,studentMarks,studentModuleMarks,studentName,studentID,testMarks,projectMarks,workshopMarks,examMarks
    if step == "sname":
      i = init(ts)
      if i != None:
        print(i)
      studentName = input("Enter student name: ")
      if not isapha(studentName) or studentName == None or studentName == "":
        print("Invalid name, please try again")
        return start("sname",ts=1)
      return start("sid",1)
    elif step == "sid":
      studentID = input("Enter student ID: ")
      if not isdigit(studentID) or studentID == None or studentID == "" or len(studentID)!=9:
        print("Invalid id, please try again")
        return start("sid",1)
      return start("testmarks",1)
    elif step == "testmarks":
      testMarks = input("Enter test marks: ")
      if not isdigit(testMarks) or testMarks == None or testMarks == "":
        print("Invalid test marks, please try again")
        return start("testmarks",1)
      return start("projectmarks",1)
    elif step == "projectmarks":
      projectMarks = input("Enter project marks: ")
      if not isdigit(projectMarks) or projectMarks == None or projectMarks == "":
        print("Invalid project marks, please try again")
        return start("projectmarks",1)
      return start("workshopmarks",1)
    elif step == "workshopmarks":
      workshopMarks = input("Enter workshop marks: ")
      if not isdigit(workshopMarks) or workshopMarks == None or workshopMarks == "":
        print("Invalid workshop marks, please try again")
        return start("workshopmarks",1)
      return start("examMarks",1)
    elif step == "examMarks":
      examMarks = input("Enter exam marks: ")
      if not isdigit(examMarks) or examMarks == None or examMarks == "":
        print("Invalid exam marks, please try again")   
        return start("examMarks",1)
    ca_marks = cal_ca_marks(testMarks,projectMarks,workshopMarks)
    module_marks = cal_module_marks(ca_marks,examMarks)
    grade = cal_grade(ca_marks,examMarks,module_marks)
    remarks, comments = return_remarks_comments(grade)
    counts += 1
    if grade == "A":
      countsA += 1
    elif grade == "B":
      countsB += 1
    elif grade == "C":
      countsC += 1
    elif grade == "F":
      countsF += 1
    studentMarks.append({"sname":studentName,"sid":studentID,"moduleMarks":module_marks})
    print(f"""
      ****************Result******************
      Student name: {studentName}
      Student ID: {studentID}
      Test Marks: {testMarks} , Project Marks: {projectMarks}, workshop marks: {workshopMarks}, exam marks: {examMarks}
      module marks: {module_marks}, module grade: {grade}, remarks: {remarks} 
      {comments}
      ****************Result******************  
     """)
    return restart()
  except ValueError:
    raise "Invalid input, please try again"
  except TypeError:
    raise "Invalid input, please try again"
  
start()