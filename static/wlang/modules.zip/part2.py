

def cal_ca_marks(testMarks:int, projectMarks:int, workshopMarks:int) -> float:
    return (testMarks*0.4)+(projectMarks*0.3)+(workshopMarks*0.3)

def cal_module_marks(caMarks:int, examMarks) -> float:
    return (caMarks*0.5)+(examMarks*0.5)

def cal_grade(caMarks:int, examMarks:int, moduleMarks:int) -> str:
    if caMarks < 40:
        grade = "F"
    elif examMarks < 40:
        grade = "F"
    elif caMarks >= 40 and examMarks >= 40 or moduleMarks >=75 and moduleMarks <= 100:
        grade = "A"
    elif caMarks >= 40 and examMarks >= 40 or moduleMarks >= 65 and moduleMarks < 75:
        grade = "B"
    elif caMarks >= 40 and examMarks >= 40 or moduleMarks >=40 and moduleMarks < 65:
        grade = "C"
    return grade

def return_remarks_comments(grade:str) -> tuple:
    pass