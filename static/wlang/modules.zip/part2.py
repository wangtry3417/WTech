

def cal_ca_marks(testMarks:int, projectMarks:int, workshopMarks:int) -> float:
    testMarks = float(testMarks)
    projectMarks = float(projectMarks)
    workshopMarks = float(workshopMarks)
    return (testMarks*0.4)+(projectMarks*0.3)+(workshopMarks*0.3)

def cal_module_marks(caMarks:int, examMarks) -> float:
    caMarks = float(caMarks)
    examMarks = float(examMarks)
    return (caMarks*0.5)+(examMarks*0.5)

def cal_grade(caMarks:int, examMarks:int, moduleMarks:int) -> str:
    caMarks = float(caMarks)
    examMarks = float(examMarks)
    moduleMarks = float(moduleMarks)
    if caMarks < 40:
        grade = "F"
    elif examMarks < 40:
        grade = "F"
    elif caMarks >= 40 and examMarks >= 40 or moduleMarks >=75 and moduleMarks <= 100:
        grade = "A"
    elif caMarks >= 40 and examMarks >= 40 or moduleMarks >= 65 and moduleMarks < 75:
        grade = "B"
    elif caMarks >= 40 and examMarks >= 40 or moduleMarks >=40 and moduleMarks < 65:
        grade = "C"
    return grade

def return_remarks_comments(grade:str) -> tuple:
    if grade == "F":
        remarks = "Restudy"
        comments = "Don't get discouraged, keep trying!"
    elif grade == "A":
        remarks = "Paas with A grade"
        comments = "Well done!"
    elif grade == "B":
        remarks = "Pass with B grade"
        comments = "Almost can get an A grade, work harder!"
    elif grade == "C":
        remarks = "Pass with C grade"
        comments = "Please be careful, you only qualified for a C."
    else:
        remarks = "Invalid Module Grade"
        comments = "Please double-check the input marks."
    return remarks,comments