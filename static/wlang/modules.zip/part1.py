from inputmask import isapha,isdigit
from part2 import cal_ca_marks,cal_grade,cal_module_marks,return_remarks_comments

try:
  studentName = input("Enter student name: ")
  if not isapha(studentName) or studentName == None or studentName == "":
    print("Invalid name, please try again")
  studentID = input("Enter student ID: ")
  if not isdigit(studentID) or studentID == None or studentID == "" or len(studentID)!=9:
    print("Invalid id, please try again")
  testMarks = input("Enter test marks: ")
  if not isdigit(testMarks) or testMarks == None or testMarks == "":
    print("Invalid test marks, please try again")
  projectMarks = input("Enter project marks: ")
  if not isdigit(projectMarks) or projectMarks == None or projectMarks == "":
    print("Invalid project marks, please try again")
  workshopMarks = input("Enter workshop marks: ")
  if not isdigit(workshopMarks) or workshopMarks == None or workshopMarks == "":
    print("Invalid workshop marks, please try again")
  examMarks = input("Enter exam marks: ")
  if not isdigit(examMarks) or examMarks == None or examMarks == "":
    print("Invalid exam marks, please try again")   
  ca_marks = cal_ca_marks(testMarks,projectMarks,workshopMarks)
  module_marks = cal_module_marks(ca_marks,examMarks)
  grade = cal_grade(ca_marks,examMarks,module_marks)
  remarks, comments = return_remarks_comments(grade)
  print(f"""
      ****************Result******************
      Student name: {studentName}
      Student ID: {studentID}
      Test Marks: {testMarks} , Project Marks: {projectMarks}, workshop marks: {workshopMarks}, exam marks: {examMarks}
      module marks: {module_marks}, module grade: {grade}, remarks: {remarks} 
      {comments}
      ****************************************  
   """)
except:
  raise Exception("Invalid input, please try again")