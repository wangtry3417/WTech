from inputmask import isapha,isdigit

try:
  studentName = input("Enter student name: ")
  if not isapha(studentName) or studentName == None or studentName == "":
    print("Invalid name, please try again")
  studentID = input("Enter student ID: ")
  if not isdigit(studentID) or studentID == None or studentID == "" or len(studentID)!=9:
    print("Invalid id, please try again")
  testMarks = input("Enter test marks: ")
  if not isdigit(testMarks) or testMarks == None or testMarks == "":
    print("Invalid test marks, please try again")
  projectMarks = input("Enter test marks: ")
  if not isdigit(projectMarks) or projectMarks == None or projectMarks == "":
    print("Invalid project marks, please try again")
  workshopMarks = input("Enter test marks: ")
  if not isdigit(workshopMarks) or workshopMarks == None or workshopMarks == "":
    print("Invalid workshop marks, please try again")
  examMarks = input("Enter test marks: ")
  if not isdigit(examMarks) or examMarks == None or examMarks == "":
    print("Invalid exam marks, please try again")   
except:
  raise Exception("Invalid input, please try again")