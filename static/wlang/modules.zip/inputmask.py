

def isapha(words:str) -> bool:
    letters = "abcdefghijklmnopqrstuvwxyz"
    return all(char in letters for char in words.lower())

def isdigit(number:int) -> bool:
    number = str(number)
    return all(num in "0123456789" for num in number)